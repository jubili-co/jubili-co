/**
 * Fixed PloyDB site-runtime client, shipped into every tenant site by the
 * sandbox image (copied to the project root as `ploy.ploydb-client.mjs`).
 *
 * The request-time read/write path for CMS-backed pages (blogs, listings,
 * directories). All the gateway plumbing — the authed fetch, row remapping, and
 * the non-obvious error semantics (degrade-to-empty reads, shed-don't-retry on
 * 429/503, timeouts) — is fixed here so Korra never regenerates it. Do not edit:
 * the sandbox regenerates this file from the image on every boot.
 *
 * `createPloyDbClient({ ployDbId, tokenEnvVar, env })` returns the helpers.
 * Pass `env` explicitly so the module stays portable across Astro versions:
 * on Astro 6 pass `import { env } from "cloudflare:workers"`; on Astro 5 pass
 * `Astro.locals.runtime.env` from inside a request handler (v5 has no
 * `cloudflare:workers` import). Both `PLOYDB_GATEWAY_URL` (auto-injected) and
 * the named token secret only exist on a published site.
 *
 * Deliberately NO `better-auth` import — this module loads on every CMS site,
 * most of which don't install better-auth. Auth lives in the separate
 * `ploy.ploydb-auth-adapter.mjs`.
 */

// True only under `astro dev` (local/in-app preview). Vite statically replaces
// `import.meta.env.DEV`, so a production build hard-codes `false` and the
// preview branch is tree-shaken — preview rows can never reach the live site.
// Guarded so the module still loads under plain Node (import.meta.env absent).
const IN_DEV_PREVIEW =
  typeof import.meta !== "undefined" &&
  import.meta.env != null &&
  import.meta.env.DEV === true;

/**
 * Read fallback for an unconfigured client (gateway URL / token not present yet,
 * as in `astro dev` preview): show the caller's sample rows in dev preview,
 * empty everywhere else. Exported for the sandbox test harness — tenant page
 * code just passes `previewRows` to `queryRows`.
 * @param {unknown[]} previewRows
 * @param {boolean} inDevPreview
 */
export function previewFallbackRows(previewRows, inDevPreview) {
  return inDevPreview ? (previewRows ?? []) : [];
}

/**
 * @param {object} options
 * @param {string} options.ployDbId - The `pdb_…` database id.
 * @param {string} options.tokenEnvVar - Name of the site secret holding the
 *   access token (owner-chosen, e.g. `BLOG_CMS_READ_TOKEN`). One client per
 *   database / token.
 * @param {Record<string, string | undefined>} options.env - The runtime env
 *   (see module note for the v5/v6 source).
 */
export function createPloyDbClient({ ployDbId, tokenEnvVar, env }) {
  if (!ployDbId) throw new Error("createPloyDbClient: ployDbId is required");
  if (!tokenEnvVar) throw new Error("createPloyDbClient: tokenEnvVar is required");
  if (!env) throw new Error("createPloyDbClient: env is required");

  const gatewayUrl = env.PLOYDB_GATEWAY_URL;
  const token = env[tokenEnvVar];
  // When the token secret isn't set yet (owner hasn't created it / republished),
  // reads degrade to empty so the page renders instead of erroring.
  const configured = Boolean(gatewayUrl && token);

  const base = `${gatewayUrl}/site/v1/ploydbs/${ployDbId}`;
  const authHeaders = { authorization: `Bearer ${token}` };
  const jsonHeaders = { ...authHeaders, "content-type": "application/json" };

  // The gateway sheds an overloaded database with 429/503 (+ Retry-After) on
  // writes. Surface a uniform try-again and STOP — never auto-retry in the
  // handler; a retry only deepens the overload.
  function throwIfShedding(response) {
    if (response.status === 429 || response.status === 503) {
      throw new Error("PloyDB is busy; please try again in a moment");
    }
  }

  // The gateway returns each row as { id, createdAt, updatedAt, values: {...} }
  // with `values` keyed by field id. Remap through the caller's field map so
  // callers read `row.title`, not `row.values.fld_…`.
  function remap(row, fields) {
    return {
      id: row.id,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      ...Object.fromEntries(
        Object.entries(fields).map(([name, fieldId]) => [
          name,
          row.values?.[fieldId],
        ])
      ),
    };
  }

  return {
    // Read rows from a table, remapped through `fields` (name → fld_ id). A
    // gateway blip (timeout, 5xx) renders empty rather than 500ing the page.
    // `body` is the query passthrough: { filters, sort, search, limit, cursor }.
    // `previewRows` (optional) are shown ONLY in local `astro dev` preview when
    // the token isn't configured yet, so the page renders with sample content;
    // a production build never returns them (see IN_DEV_PREVIEW).
    async queryRows(tableId, fields, body = {}, previewRows = []) {
      if (!configured) return previewFallbackRows(previewRows, IN_DEV_PREVIEW);
      try {
        const response = await fetch(`${base}/tables/${tableId}/query`, {
          method: "POST",
          headers: jsonHeaders,
          body: JSON.stringify(body),
          signal: AbortSignal.timeout(5000),
        });
        if (!response.ok)
          throw new Error(`PloyDB query failed: ${response.status}`);
        const { rows } = await response.json();
        return (rows ?? []).map((row) => remap(row, fields));
      } catch (error) {
        // Do NOT retry inline — a retry deepens an overload. Render empty and let
        // the page's Cache-Control keep a stale-but-good copy serving.
        console.error("PloyDB query failed; rendering empty", error);
        return [];
      }
    },

    // Insert a row. `values` keyed by field id. Returns the created row's
    // identity ({ id, createdAt, updatedAt }); column values come back only with
    // a read grant on the table (a write-only token gets identity only).
    async insertRow(tableId, values) {
      if (!token) throw new Error("PloyDB token not set");
      const response = await fetch(`${base}/tables/${tableId}/rows`, {
        method: "POST",
        headers: jsonHeaders,
        body: JSON.stringify({ values }),
        signal: AbortSignal.timeout(5000),
      });
      throwIfShedding(response);
      if (!response.ok)
        throw new Error(`PloyDB insert failed: ${response.status}`);
      const { row } = await response.json();
      return row ?? null;
    },

    // Patch only the keys you pass; `values` keyed by field id. Address the row
    // by its `id` (from a prior query). Returns the updated row when the token
    // can read the table, else null (write-only key).
    async updateRow(tableId, rowId, values) {
      if (!token) throw new Error("PloyDB token not set");
      const response = await fetch(`${base}/tables/${tableId}/rows/${rowId}`, {
        method: "PATCH",
        headers: jsonHeaders,
        body: JSON.stringify({ values }),
        signal: AbortSignal.timeout(5000),
      });
      throwIfShedding(response);
      if (!response.ok)
        throw new Error(`PloyDB update failed: ${response.status}`);
      const { row } = await response.json();
      return row ?? null;
    },

    // Delete a single row by id. Treat a 2xx as success.
    async deleteRow(tableId, rowId) {
      if (!token) throw new Error("PloyDB token not set");
      const response = await fetch(`${base}/tables/${tableId}/rows/${rowId}`, {
        method: "DELETE",
        headers: authHeaders,
        signal: AbortSignal.timeout(5000),
      });
      throwIfShedding(response);
      if (!response.ok)
        throw new Error(`PloyDB delete failed: ${response.status}`);
    },

    // Atomic multi-op write — the whole `operations` array commits or rolls back
    // together. Every op's table must be in the token's write scope. NOT
    // idempotent (server-minted ids, no dedup key) — never blind-retry; re-derive
    // the intended state and issue targeted ops instead.
    async batchWrite(operations) {
      if (!token) throw new Error("PloyDB token not set");
      const response = await fetch(`${base}/batch`, {
        method: "POST",
        headers: jsonHeaders,
        body: JSON.stringify({ operations }),
        signal: AbortSignal.timeout(5000),
      });
      throwIfShedding(response);
      if (!response.ok)
        throw new Error(`PloyDB batch failed: ${response.status}`);
      const { results } = await response.json();
      return results ?? [];
    },
  };
}
