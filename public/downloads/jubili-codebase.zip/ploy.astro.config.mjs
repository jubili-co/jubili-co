// This is the PloyBox Astro dev wrapper. It is copied into tenant projects as
// ploy.astro.config.mjs so Ploy can force preview/runtime settings while still
// extending the tenant's own astro.config.* when one exists.

// @ts-check
import { existsSync } from 'fs';
import { utimes } from 'fs/promises';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { defineConfig } from 'astro/config';
import tailwindcss from '@tailwindcss/vite';
import sitemap from '@astrojs/sitemap';
import react from '@astrojs/react';
import cloudflare from '@astrojs/cloudflare';
import { ployDevPagesManifest } from '/ploy/etc/astro/dev-pages-manifest.mjs';
import {
  loadTenantAstroConfig,
  mergePloyAstroConfig,
} from '/ploy/etc/astro/merge-astro-config.mjs';

// Resolve @astrojs/cloudflare's installed major so we can shape adapter
// options correctly. v12 (Astro 5) wraps the wrangler config under
// `platformProxy: { enabled, configPath }`; v13+ (Astro 6) flattened the API
// to a top-level `configPath` and removed the `platformProxy` wrapper.
// Passing the wrong shape errors out of astro dev — and this file is baked
// into every sandbox image, so it has to handle both starter versions.
const adapterRequire = createRequire(import.meta.url);
let astroCloudflareAdapterMajor = 13;
try {
  const adapterPkg = adapterRequire('@astrojs/cloudflare/package.json');
  const major = parseInt(String(adapterPkg.version).split('.')[0], 10);
  if (Number.isFinite(major)) astroCloudflareAdapterMajor = major;
} catch {
  // Fall back to 13 (current tenant-starter-astro pin) if detection fails.
}
// Prefer wrangler.jsonc (the format publish writes; canonical going forward)
// and fall back to wrangler.toml so tenants still shipping the legacy format
// keep working. Resolved at module load against this config file's directory,
// which is the tenant project root after PloyBox copies us there at startup.
const WRANGLER_CONFIG_PATH = existsSync(
  new URL('./wrangler.jsonc', import.meta.url)
)
  ? './wrangler.jsonc'
  : './wrangler.toml';

const cloudflareAdapterOptions =
  astroCloudflareAdapterMajor >= 13
    ? { configPath: WRANGLER_CONFIG_PATH }
    : { platformProxy: { enabled: true, configPath: WRANGLER_CONFIG_PATH } };

// Absolute path to xxhash-wasm's ESM variant, used as a Vite alias target
// below. We need an absolute path (not a package subpath) because
// xxhash-wasm's `exports` map only exposes "." and doesn't expose
// `./esm/...` or `./package.json` — so createRequire.resolve and
// subpath aliases both fail. Resolving relative to this config file's
// directory is safe: Astro projects always have node_modules colocated
// with the project root where this config lives.
const CONFIG_DIR = dirname(fileURLToPath(import.meta.url));
const XXHASH_WASM_ESM_PATH = join(
  CONFIG_DIR,
  'node_modules/xxhash-wasm/esm/xxhash-wasm.js'
);

// ============================================================================
// PLOY TAILWIND CONTENT HMR PLUGIN
// ============================================================================
//
// Workaround: @tailwindcss/vite v4 doesn't rescan for utility classes when
// NEW content files are created on disk, because:
//
//   1. requiresBuild() only tracks CSS dependency mtimes, not template files.
//   2. The hotUpdate handler exits early for new files (modules.length === 0).
//
// When Rosetta/Korra write new .astro/.tsx files via the controller API,
// Tailwind never sees the new utility classes and CSS output is stale.
//
// Fix: listen for new content files via chokidar's "add" event, then touch
// a tracked CSS file's mtime so requiresBuild() returns true on the next CSS
// request. Emit a synthetic "change" event so Vite routes the update through
// its normal HMR pipeline — Tailwind rescans, CSS regenerates, and the
// browser receives a CSS-only HMR update (no full page reload).
//
// See: https://github.com/Ploy-AI/ploy-world/issues/1605
// ============================================================================

const CONTENT_FILE_RE = /\.(astro|tsx|jsx|ts|js|html|svelte|vue|mdx?)$/;

// Paths whose writes must NOT trigger a Tailwind rescan. workerd's
// .wrangler/tmp/deploy-*/index.js writes and vite's optimized-dep writes
// both match CONTENT_FILE_RE on .js, creating a feedback loop:
// write → rescan → CSS HMR → workerd/dep re-emits → write → ...
// See sandbox-hmr-loop investigation handoff.
const IGNORED_CONTENT_PATH_RE =
  /[/\\](?:\.wrangler|node_modules|\.vite-dev|\.vite-build|\.astro|dist|logs)[/\\]/;

/** @returns {import("vite").Plugin} */
function ployTailwindContentHmrPlugin() {
  return {
    name: 'ploy-tailwind-content-hmr',

    /** @param {import("vite").ViteDevServer} server */
    configureServer(server) {
      /** @type {ReturnType<typeof setTimeout> | null} */
      let pendingRefresh = null;

      // NOTE: Only "add" (new files) is handled here. The same requiresBuild()
      // gap affects "change" events on existing files too — if Korra edits an
      // existing .astro file and adds a new TW class, Tailwind won't rescan.
      // We skip "change" for now because: (1) Rosetta page clones (new files)
      // are the primary case, (2) edits to existing files mostly reuse classes
      // already in CSS, (3) listening to "change" triggers a rescan on every
      // file save which adds CPU overhead. If this becomes a problem, add
      // "change" here — the rest of the logic is the same.
      server.watcher.on('add', (/** @type {string} */ filePath) => {
        // Only care about content files that Tailwind would scan
        if (!CONTENT_FILE_RE.test(filePath)) return;
        if (IGNORED_CONTENT_PATH_RE.test(filePath)) return;

        // Debounce: batch rapid writes (Rosetta uploads multiple files)
        if (pendingRefresh) clearTimeout(pendingRefresh);
        pendingRefresh = setTimeout(async () => {
          // Find a project CSS file tracked by Vite's module graph
          for (const mod of server.moduleGraph.idToModuleMap.values()) {
            if (
              !mod.file?.endsWith('.css') ||
              mod.file.includes('node_modules')
            ) {
              continue;
            }

            try {
              // Bump mtime so @tailwindcss/vite's requiresBuild() returns true
              const now = new Date();
              await utimes(mod.file, now, now);
              // Emit synthetic change — Vite handles HMR from here
              server.watcher.emit('change', mod.file);
            } catch {
              // CSS file may have been deleted; skip
            }
            break; // One CSS file is enough to trigger a full rescan
          }
        }, 500);
      });
    },
  };
}

// HMR WebSocket config: hardcoded wss because ploy-preview's WS mux expects
// wss://{preview.host}/ and browsers (mixed-content rules) can't make a ws://
// connection from an https page. Vite bakes this single value into the
// @vite/client module at serve time — one bundle serves both contexts.
//
// Trade-off: headless smoke-check hitting http://localhost:3000 directly
// cannot use HMR (browser tries wss://localhost:3000 → SSL error). This means
// Vite's error overlay never surfaces on the direct-to-sandbox path. The
// smoke-check uses `--tail-log` to read the dev-server log instead, which
// has the error text Vite would have shown in the overlay.
//
// If this trade-off needs to change, the path is to serve different
// @vite/client content based on the request's Host/Referer (custom Vite
// middleware) — out of scope for now.
const hmrConfig = {
  protocol: 'wss',
  overlay: true,
};

// Isolate dev's vite optimizer cache from `astro check` / `build` /
// `sync` (which `bun run verify` runs concurrently with dev). Sharing
// the default `node_modules/.vite` causes verify to clobber dev's
// `_metadata.json` mid-flight → 504 on stale `deps/*.js?v=...` URLs.
const astroCommand = process.argv.slice(2).find((arg) => !arg.startsWith('-'));
const viteCacheDir =
  astroCommand === 'dev' || astroCommand === 'preview'
    ? 'node_modules/.vite-dev'
    : 'node_modules/.vite-build';

const tenantAstroConfig = await loadTenantAstroConfig(import.meta.url, {
  configArgs: {
    command: astroCommand || 'dev',
    mode: process.env.NODE_ENV || 'development',
  },
});

const ployAstroConfig = {
  site:
    process.env.PLOY_TENANT_DOMAIN ||
    `https://${process.env.PLOY_TENANT_APP_PREVIEW_PORT}.${process.env.DAYTONA_SANDBOX_ID}.ploy.build`,
  output: 'server',
  adapter: cloudflare({
    imageService: 'compile',
    // Adapter shape differs between v12 and v13 — see
    // `cloudflareAdapterOptions` definition near the top of this file.
    ...cloudflareAdapterOptions,
  }),
  integrations: [sitemap(), react(), ployDevPagesManifest()],
  vite: {
    cacheDir: viteCacheDir,
    plugins: [
      tailwindcss(),
      // Workaround: @tailwindcss/vite doesn't rescan when new content files
      // are created. Triggers CSS rebuild by touching a tracked CSS file.
      // See: ployTailwindContentHmrPlugin() definition above.
      ployTailwindContentHmrPlugin(),
      // Workaround: Daytona proxy mishandles HTTP 304 responses as 400 Bad Request.
      // Strip conditional request headers so Vite always returns 200 with full content.
      // See: src/ploy-app/docs/research/daytona/2026-01-20-daytona-proxy-304-issue.md
      {
        name: 'daytona-304-workaround',
        /** @param {import("vite").ViteDevServer} server */
        configureServer(server) {
          server.middlewares.use((req, _res, next) => {
            delete req.headers['if-none-match'];
            delete req.headers['if-modified-since'];
            next();
          });
        },
      },
      // Workaround: Blaxel's preview proxy passes bl_preview_token query param
      // through to the origin app. Vite uses the full URL (including query params)
      // as the module cache key, so ?bl_preview_token=... causes:
      //   - __DEFINES__ not replaced in env.mjs (treated as different module)
      //   - Astro virtual modules (before-hydration.js) return 404
      // Strip the token before Vite's module resolution sees it.
      {
        name: 'blaxel-strip-auth-token',
        /** @param {import("vite").ViteDevServer} server */
        configureServer(server) {
          server.middlewares.use((req, _res, next) => {
            if (req.url?.includes('bl_preview_token')) {
              const url = new URL(req.url, 'http://localhost');
              url.searchParams.delete('bl_preview_token');
              req.url = url.pathname + url.search;
            }
            next();
          });
        },
      },
    ],
    resolve: {
      conditions: ['workerd', 'worker', 'browser'],
      alias: {
        // Force xxhash-wasm to the base64-inlined ESM variant.
        // Astro calls xxhash during `astro sync` for content-collection
        // hashing, which runs on every config-reload restart (e.g. after
        // `bun add`). The `workerd` variant — selected by our resolve
        // conditions — does `import wasm from "./xxhash.wasm"` expecting a
        // default export, which Node 24 ESM no longer provides. Without
        // this alias the restart throws GenerateContentTypesError, Astro
        // catches it and "continues with previous valid configuration",
        // but the HTTP server's port-3000 binding gets dropped in that
        // recovery path — leaving the Caddy reverse_proxy (:8000 → :3000)
        // serving its 503 "warming up" response indefinitely. See
        // XXHASH_WASM_ESM_PATH computation at top of file for the reason
        // we use an absolute path here instead of a package subpath.
        'xxhash-wasm': XXHASH_WASM_ESM_PATH,
        // React 19 SSR: use server.edge instead of server.browser in prod
        // builds — avoids needing a MessageChannel polyfill for
        // node:worker_threads.
        ...(import.meta.env.PROD
          ? { 'react-dom/server': 'react-dom/server.edge' }
          : {}),
      },
    },
    ssr: {
      resolve: {
        conditions: ['workerd', 'worker', 'node'],
        externalConditions: ['workerd', 'worker', 'node'],
      },
    },
    server: {
      hmr: hmrConfig,
      // Fail fast if the port is already in use instead of silently picking
      // a random one — sandbox expects to find the app on this exact port.
      strictPort: true,
      watch: {
        // Ignore paths that churn from build/runtime output, not user edits.
        // - logs/: stdout tee
        // - .wrangler/: workerd deploy bundles (platformProxy spawns workerd)
        // - node_modules/, .vite-dev/, .vite-build/: vite dep optimizer rewrites
        // - .astro/, dist/: astro build output
        // Without these, watcher `add` events feed ployTailwindContentHmrPlugin,
        // CSS HMR fires, the toolchain re-emits, and the dev server wedges.
        ignored: [
          '**/logs/**',
          '**/.wrangler/**',
          '**/node_modules/**',
          '**/.vite-dev/**',
          '**/.vite-build/**',
          '**/.astro/**',
          '**/dist/**',
        ],
      },
    },
  },
  server: {
    host: '0.0.0.0', // Bind all interfaces — required for Blaxel's external preview proxy
    port: parseInt(process.env.PLOY_TENANT_APP_PREVIEW_PORT || '3000'),
    open: false,
    allowedHosts: [
      '.localhost',
      '.runploy.com',
      '.ploy.ai',
      '.ploy.build',
      '.ploy.live',
      '.ploy.site',
      // Daytona proxy hosts
      `${process.env.PLOY_TENANT_APP_PREVIEW_PORT}-${process.env.DAYTONA_SANDBOX_ID}.localhost`,
      `${process.env.PLOY_TENANT_APP_PREVIEW_PORT}-${process.env.DAYTONA_SANDBOX_ID}.proxy.daytona.works`,
      `${process.env.CADDY_PORT}-${process.env.DAYTONA_SANDBOX_ID}.localhost`,
      `${process.env.CADDY_PORT}-${process.env.DAYTONA_SANDBOX_ID}.proxy.daytona.works`,
      // Blaxel proxy hosts (external preview and internal AWS routing)
      '.bl.run',
      '.beamlit.net',
    ],
  },
  devToolbar: {
    enabled: false,
  },
};

// https://astro.build/config
export default defineConfig(
  mergePloyAstroConfig(tenantAstroConfig, ployAstroConfig)
);
