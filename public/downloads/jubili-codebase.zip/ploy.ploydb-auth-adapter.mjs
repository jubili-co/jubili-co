/**
 * Fixed PloyDB ↔ Better Auth adapter, shipped into every tenant site by the
 * sandbox image (copied to the project root as `ploy.ploydb-auth-adapter.mjs`).
 *
 * The per-site inputs are the database id, the table/field id map, and the
 * runtime `env`, all passed to `createPloyDbAdapter({ ployDbId, models, env })`
 * from the tenant's `auth.ts`. Everything error-prone — the Better Auth adapter
 * contract, the gateway calls, system-column mapping, and filter push-down —
 * lives here as fixed code so Korra never has to regenerate it. Do not edit: the
 * sandbox regenerates this file from the image on every boot.
 *
 * Runtime contract (same as the `ploydb` skill):
 * - `env` is passed in, not imported, so this works on both Astro 6 and Astro 5.
 *   Source it from `import { env } from "cloudflare:workers"` on Astro 6 (the
 *   starter), or `context.locals.runtime.env` on legacy Astro 5 (which has no
 *   `cloudflare:workers` import). Only present on a published site, so auth calls
 *   fail in `astro dev` by design.
 * - `PLOYDB_GATEWAY_URL` is auto-injected; the access token is an owner-set
 *   secret named by `tokenEnvVar` (default `SITE_AUTH_PLOYDB_TOKEN`), read +
 *   write on the four Better Auth tables.
 */

import { createAdapterFactory } from "better-auth/adapters";

// Better Auth's id/createdAt/updatedAt ARE PloyDB's system columns: they live at
// the row's top level (not in `values`), are addressed by these reserved names
// in filters/sorts, and `id` is set on insert via the row id — never a column.
const SYSTEM_FIELDS = {
  id: "id",
  createdAt: "created_at",
  updatedAt: "updated_at",
};

// Filters the gateway can evaluate server-side. Anything else is matched in the
// Worker after paging (see `matches`).
const GATEWAY_FILTER_OPS = {
  eq: "eq",
  ne: "neq",
  gt: "gt",
  gte: "gte",
  lt: "lt",
  lte: "lte",
  contains: "contains",
};

const DEFAULT_TOKEN_ENV_VAR = "SITE_AUTH_PLOYDB_TOKEN";

/**
 * @param {object} options
 * @param {string} options.ployDbId - The `pdb_…` database id.
 * @param {Record<string, { tableId: string, fields: Record<string, string> }>} options.models
 *   - Better Auth model name → its `tbl_…` id + a map of real Better Auth field
 *     name → `fld_…` id. Never include id/createdAt/updatedAt (system columns).
 * @param {string} [options.tokenEnvVar] - Access-token secret name.
 * @param {Record<string, string | undefined>} options.env - The runtime env
 *   (see module note for the Astro 5/6 source).
 */
export function createPloyDbAdapter({
  ployDbId,
  models,
  tokenEnvVar = DEFAULT_TOKEN_ENV_VAR,
  env,
}) {
  if (!ployDbId) throw new Error("createPloyDbAdapter: ployDbId is required");
  if (!models) throw new Error("createPloyDbAdapter: models is required");
  if (!env) throw new Error("createPloyDbAdapter: env is required");

  function model(name) {
    const m = models[name];
    if (!m) throw new Error(`Unsupported auth model: ${name}`);
    return m;
  }

  // Gateway routes for a model's table and a single row within it.
  const tablePath = (name) =>
    `/site/v1/ploydbs/${ployDbId}/tables/${model(name).tableId}`;
  const rowPath = (name, rowId) => `${tablePath(name)}/rows/${rowId}`;

  // Gateway field name for a Better Auth field: a system column, a real column's
  // fld_ id, or null when unknown (not pushable → Worker-side match).
  function gatewayField(name, field) {
    if (field in SYSTEM_FIELDS) return SYSTEM_FIELDS[field];
    return model(name).fields[field] ?? null;
  }

  function toScalar(value) {
    if (value instanceof Date) return value.toISOString();
    if (typeof value === "boolean") return value ? 1 : 0;
    if (value === undefined) return null;
    return value;
  }

  async function gateway(path, init) {
    const token = env[tokenEnvVar];
    const gatewayUrl = env.PLOYDB_GATEWAY_URL;
    if (!gatewayUrl || !token)
      throw new Error("PloyDB auth not configured (publish the site).");
    const res = await fetch(`${gatewayUrl}${path}`, {
      ...init,
      headers: {
        authorization: `Bearer ${token}`,
        "content-type": "application/json",
        ...init.headers,
      },
      signal: AbortSignal.timeout(5000),
    });
    // Gateway is shedding (429/503 + Retry-After). Surface try-again and STOP —
    // never auto-retry; a retry only deepens the overload (same shed-don't-retry
    // contract as the CMS client's write paths).
    if (res.status === 429 || res.status === 503)
      throw new Error("PloyDB is busy; please try again in a moment");
    if (!res.ok) throw new Error(`PloyDB ${init.method} failed: ${res.status}`);
    return res.status === 204 ? null : res.json();
  }

  // A gateway row { id, createdAt, updatedAt, values: { fld_…: … } } → a flat
  // Better Auth record keyed by field name.
  function fromRow(name, row) {
    const { fields } = model(name);
    return {
      id: row.id,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      ...Object.fromEntries(
        Object.entries(fields).map(([field, id]) => [field, row.values?.[id]])
      ),
    };
  }

  // Better Auth data → gateway `values`, keyed by field id. System fields and
  // undefined are dropped (id/createdAt/updatedAt never go in `values`).
  function toValues(name, data) {
    const { fields } = model(name);
    return Object.fromEntries(
      Object.entries(data)
        .filter(([field, v]) => field in fields && v !== undefined)
        .map(([field, v]) => [fields[field], toScalar(v)])
    );
  }

  // Page the table (cursor), pushing a single supported filter to the gateway so
  // a hot lookup by email/token doesn't pull every row.
  async function readRows(name, where = []) {
    const op = where.length === 1 && GATEWAY_FILTER_OPS[where[0].operator];
    const field = where.length === 1 ? gatewayField(name, where[0].field) : null;
    const pushable =
      op &&
      field &&
      !Array.isArray(where[0].value) &&
      typeof where[0].value !== "boolean" &&
      // The gateway matches case-sensitively; an insensitive filter must page
      // and be matched Worker-side (see `matches`) or it would drop valid rows.
      where[0].mode !== "insensitive";
    const body = { limit: 500 };
    if (pushable) {
      body.filters = [{ field, op, value: toScalar(where[0].value) }];
    }
    const out = [];
    let cursor;
    do {
      const page = await gateway(`${tablePath(name)}/query`, {
        method: "POST",
        body: JSON.stringify(cursor ? { ...body, cursor } : body),
      });
      for (const row of page?.rows ?? [])
        out.push({ rowId: row.id, record: fromRow(name, row) });
      cursor = page?.hasMore ? page.nextCursor : undefined;
    } while (cursor);
    return out;
  }

  function matches(record, where = []) {
    return where.every((c) => {
      // Lower-case strings (scalars and array elements) under insensitive mode.
      const norm = (v) =>
        c.mode === "insensitive" && typeof v === "string" ? v.toLowerCase() : v;
      const a = norm(record[c.field]);
      const e = Array.isArray(c.value) ? c.value.map(norm) : norm(c.value);
      switch (c.operator) {
        case "eq":
          return a === e;
        case "ne":
          return a !== e;
        case "in":
          return Array.isArray(e) && e.includes(a);
        case "not_in":
          return Array.isArray(e) && !e.includes(a);
        case "contains":
          return a != null && String(a).includes(String(e));
        case "starts_with":
          return a != null && String(a).startsWith(String(e));
        case "ends_with":
          return a != null && String(a).endsWith(String(e));
        // Comparisons work for numbers and ISO-8601 dates (session expiresAt).
        case "gt":
          return a > e;
        case "gte":
          return a >= e;
        case "lt":
          return a < e;
        case "lte":
          return a <= e;
        default:
          return false;
      }
    });
  }

  return createAdapterFactory({
    config: {
      adapterId: "ploydb",
      adapterName: "PloyDB",
      supportsJSON: false,
      supportsDates: false,
      supportsBooleans: false,
      supportsNumericIds: false,
      // No interactive transactions; Better Auth doesn't require one here.
      transaction: false,
    },
    adapter: () => ({
      create: async ({ model: name, data }) => {
        // Better Auth's `id` becomes the row id (system column), not a value.
        const { id, ...rest } = data;
        await gateway(`${tablePath(name)}/rows`, {
          method: "POST",
          body: JSON.stringify({
            ...(id !== undefined ? { rowId: id } : {}),
            values: toValues(name, rest),
          }),
        });
        return data;
      },
      findOne: async ({ model: name, where }) =>
        (await readRows(name, where)).find((r) => matches(r.record, where))
          ?.record ?? null,
      findMany: async ({ model: name, where, limit, offset = 0, sortBy }) => {
        const rows = (await readRows(name, where))
          .map((r) => r.record)
          .filter((r) => matches(r, where));
        if (sortBy) {
          rows.sort((l, r) =>
            String(l[sortBy.field]).localeCompare(String(r[sortBy.field]))
          );
          if (sortBy.direction === "desc") rows.reverse();
        }
        return rows.slice(offset, limit ? offset + limit : undefined);
      },
      count: async ({ model: name, where }) =>
        (await readRows(name, where)).filter((r) => matches(r.record, where))
          .length,
      update: async ({ model: name, where, update }) => {
        const hit = (await readRows(name, where)).find((r) =>
          matches(r.record, where)
        );
        if (!hit) return null;
        await gateway(rowPath(name, hit.rowId), {
          method: "PATCH",
          body: JSON.stringify({ values: toValues(name, update) }),
        });
        return { ...hit.record, ...update };
      },
      updateMany: async ({ model: name, where, update }) => {
        const hits = (await readRows(name, where)).filter((r) =>
          matches(r.record, where)
        );
        await Promise.all(
          hits.map((h) =>
            gateway(rowPath(name, h.rowId), {
              method: "PATCH",
              body: JSON.stringify({ values: toValues(name, update) }),
            })
          )
        );
        return hits.length;
      },
      delete: async ({ model: name, where }) => {
        const hit = (await readRows(name, where)).find((r) =>
          matches(r.record, where)
        );
        if (hit) await gateway(rowPath(name, hit.rowId), { method: "DELETE" });
      },
      deleteMany: async ({ model: name, where }) => {
        const hits = (await readRows(name, where)).filter((r) =>
          matches(r.record, where)
        );
        await Promise.all(
          hits.map((h) => gateway(rowPath(name, h.rowId), { method: "DELETE" }))
        );
        return hits.length;
      },
    }),
  });
}
